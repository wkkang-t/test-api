package controllers

import (
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
	"github.com/dgrijalva/jwt-go"
	"test-api/models"
	"time"
)

type UserController struct {
	// 这是匿名内部类的写法。也可以理解为继承
	BaseController
}

// this可以换成任意词汇，但是习惯上使用this。
// TODO:问题1：为什么要使用 *，与不使用*有什么差别
func (this *UserController) Login() {
	token, err := generateToken(1)
	// 这里偷懒了，不去数据库查询
	if err != nil {
		this.Error(500, "token生成失败")
	} else {
		this.Success(token)
	}
}

func (this *UserController) User() {
	// 从header中 token 标签 获取token内容。当然，这个key可以是任意值（但是前后端需要统一）。
	// 不建议使用 authorization 字段，TODO:问题5：为什么不建议，会产生什么问题
	token := this.Ctx.Input.Header("token")
	if len(token) == 0 {
		this.Error(405, "token is empty")
		return
		// TODO:问题4：这个return会被执行吗。加一个return有什么用途
	}

	user := this.GetUserFromToken()
	if user == nil {
		this.Error(405, "无对应信息")
		return
	}

	this.Success(user)
}

func (this *UserController) UpdateUser() {
	user := models.User{Name: "xxx", Age: 1, CommonModel: models.CommonModel{CreateTime: 2, UpdateTime: 3}}

	updateName(&user)

	updateTime(user)

	// TODO:问题12：这里的实际输出（返回）结果是什么
	this.Success(user)
}

func updateName(user *models.User) {
	user.Name = "update" + user.Name
}

func updateTime(user models.User) {
	user.UpdateTime = time.Now().Unix()
}

// 这个方法（函数）不属于具体某一个 “struct” 的方法，因此，任何地方都可以调用
// TODO:问题6：真的任何地方都可以调用吗？为什么
func generateToken(userId int) (string, error) {
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"userId": userId,
		//"exp":      time.Now().Add(time.Hour * 2).Unix(),// 可以添加过期时间
	})

	//对应的字符串请自行生成，最后足够使用加密后的字符串
	return token.SignedString([]byte("123"))
}

// ------------- 这是封装的类库。理论上应该写在另外一个go文件中，这里偷懒了
type BaseController struct {
	beego.Controller
}

func (this *BaseController) Success(data interface{}) {
	this.Data["json"] = beego.M{"code": 200, "data": data}
	// TODO:问题2：这个func ServeJSON 可以传参（encoding），用途是什么
	this.ServeJSON()
	this.StopRun()
}

func (this *BaseController) Error(code int, msg ...string) {
	this.Data["json"] = beego.M{"code": code, "msg": msg}
	this.ServeJSON()
	this.StopRun()
}

func (this *BaseController) GetUserFromToken() *models.User {
	tokenStr := this.Ctx.Input.Header("token")
	if tokenStr == "" {
		return nil
	} else {
		token, _ := jwt.Parse(tokenStr, func(token *jwt.Token) (interface{}, error) {
			if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
				return nil, nil
			}
			return []byte("secret"), nil
		})
		if !token.Valid {
			return nil
		} else {
			var user models.User
			// TODO:问题7：token.Claims.(jwt.MapClaims) 这是什么意思
			// TODO:问题8：.One(&user) 这里为什么需要加 “&”符号
			if err := orm.NewOrm().QueryTable(new(models.User)).Filter("Id", token.Claims.(jwt.MapClaims)["userId"]).One(&user); err != nil {
				return nil
			}

			// orm执行原生sql
			// var userList []models.User
			// orm.NewOrm().Raw("select a1.*,a2.* from user a1 left join teacher a2 on a1.teacher_id=a2.id limit ?, ?;", 0, 10).QueryRows(&userList)
			// logs.debug(userList)

			// TODO:问题9：这里为什么需要加 “&”符号
			return &user
		}
	}
}
