package main

import (
	"github.com/astaxie/beego"
)

/**
目标：
1、项目能跑起来，保证访问API后有数据输出
2、回答项目中所有的TODO问题

*/
func main() {
	if beego.BConfig.RunMode == "dev" {
		beego.BConfig.WebConfig.DirectoryIndex = true
		beego.BConfig.WebConfig.StaticDir["/swagger"] = "swagger"
	}

	beego.Run()
}
