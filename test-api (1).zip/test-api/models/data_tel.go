package models

import "github.com/astaxie/beego/orm"

// 电话记录表
type DataTel struct {
	Id         int64  `orm:"auto;pk"`
	Tel        string `orm:"size(20)"`
	CreateTime int64
}

func init() {
	orm.RegisterModel(new(DataTel))
}
