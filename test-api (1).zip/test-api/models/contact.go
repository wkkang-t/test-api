package models

import "github.com/astaxie/beego/orm"

type Contact struct {
	Id         int64 `orm:"auto;pk"`
	UserId     int64
	RawJson    string `orm:"type(text)"`
	CreateTime int64
}

func init() {
	orm.RegisterModel(new(Contact))
}


type ReqContact struct {
	FirstName  string              `json:"firstName"`
	MiddleName string              `json:"middleName"`
	LastName   string              `json:"lastName"`
	Prefix     string              `json:"prefix"`
	Suffix     string              `json:"suffix"`
	FullName   string              `json:"fullName"`
	Email      string              `json:"email"`
	Address    ReqContactAddress   `json:"address"`
	Company    string              `json:"company"`
	Title      string              `json:"title"`
	Note       string              `json:"note"`
	Phones     []map[string]string `json:"phones"`
}

type ReqContactAddress struct {
	Country string `json:"Country"`
	City    string `json:"City"`
	Street  string `json:"Street"`
	State   string `json:"State"`
	Zip     string `json:"ZIP"`
}
