package models

import "github.com/astaxie/beego/orm"

// TODO:问题3：这个func会在什么时间执行。如果 main.go 里面也有这个func，那么执行顺序是怎么样的
func init() {
	orm.RegisterModel(new(User) /*, new(xxx) 可以添加多个*/)
}
