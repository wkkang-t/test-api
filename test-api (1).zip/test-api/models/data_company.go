package models

import "github.com/astaxie/beego/orm"

// 公司记录
type DataCompany struct {
	Id         int64  `orm:"auto;pk"`
	Name       string `orm:"size(50)"`
	Address    string `orm:"size(100)"`
	CreateTime int64
	UpdateTime int64
}

func init() {
	orm.RegisterModel(new(DataCompany))
}
