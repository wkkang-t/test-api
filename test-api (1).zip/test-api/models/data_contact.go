package models

import "github.com/astaxie/beego/orm"

// 联系人表
type DataContact struct {
	Id          int64  `orm:"auto;pk"`
	TelId       int64  `orm:"not null;description(关联电话)"`
	EmailId     int64  `orm:"null;description(关联邮箱)"`
	ContactName string `orm:"size(50)"`
	Address     string `orm:"size(100)"`
	Weights     int    `orm:"description(权重)"`
	CreateTime  int64
	UpdateTime  int64
}

func init() {
	orm.RegisterModel(new(DataContact))
}
