package models

import "github.com/astaxie/beego/orm"

// 邮箱记录表
type DataEmail struct {
	Id         int64  `orm:"auto;pk"`
	Email      string `orm:"size(100)"`
	CreateTime int64
}

func init() {
	orm.RegisterModel(new(DataEmail))
}
