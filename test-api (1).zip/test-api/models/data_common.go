package models

type CommonTable struct {
	Id         int64
	CreateTime int64
}
