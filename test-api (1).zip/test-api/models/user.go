package models

type User struct {
	// TODO:问题10：这样写，实际生成的表是什么样子
	CommonModel
	// TODO:问题11：orm:"xxxx" 与 json 的用途分别是什么
	Name        string `orm:"column(user_name)" json:"name"`
	Age         int
	Gender      int
	Password    string `json:"-"`          // TODO:问题13：这是什么意思，为什么要这样写
	PhoneNumber string `json:",omitempty"` // TODO:问题14：这是什么意思，为什么要这样写
}

type CommonModel struct {
	Id         int64
	CreateTime int64
	UpdateTime int64
	Deleted    bool
}
